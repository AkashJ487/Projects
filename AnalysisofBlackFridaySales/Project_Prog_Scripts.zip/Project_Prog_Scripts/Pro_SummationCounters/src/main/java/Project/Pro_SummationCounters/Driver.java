package Project.Pro_SummationCounters;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Driver {

	public static void main(String[] args) throws Exception {
		
		Path inputPath = new Path(args[0]);
		Path outputDir = new Path(args[1]);
		
		Configuration conf = new Configuration();
		Job job;
		try {
			job = Job.getInstance(conf);
			job.setJarByClass(CityMapper.class);
			
			job.setMapperClass(CityMapper.class);
			job.setMapOutputKeyClass(NullWritable.class);
			job.setMapOutputValueClass(NullWritable.class);
			
			job.setInputFormatClass(TextInputFormat.class);
			FileInputFormat.addInputPath(job, inputPath);
			
			FileOutputFormat.setOutputPath(job, outputDir);
			
			FileSystem hdfs = FileSystem.get(conf);
			
			if (hdfs.exists(outputDir)){
				hdfs.delete(outputDir, true);
			}
			
			int code = job.waitForCompletion(true) ? 0 : 1;
			
			if(code==0)
			{
				for(Counter counter : job.getCounters().getGroup(CityMapper.CityCounterGroup))
				{
					System.out.println(counter.getDisplayName()+"\t"+counter.getValue());
				}
			}
			FileSystem.get(conf).delete(outputDir,true);
			System.exit(code);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
