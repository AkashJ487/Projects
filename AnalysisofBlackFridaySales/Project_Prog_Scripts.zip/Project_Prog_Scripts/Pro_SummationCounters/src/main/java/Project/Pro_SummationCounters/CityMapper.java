package Project.Pro_SummationCounters;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CityMapper extends Mapper<Object,Text,NullWritable,NullWritable> {
	
	public static final String CityCounterGroup="City";
	public static final String CityA="A";
	public static final String CityB="B";
	public static final String CityC="C";
	public static final String CityAll="Total";
	
	@Override
	public void map(Object key, Text value, Context context)
			throws IOException, InterruptedException {
		
		String values[] = value.toString().split(",");
		try
		{
			if(!values[0].equals("User_ID"))
			{
				if(values[5].equals(CityA))
					context.getCounter(CityCounterGroup,CityA).increment(Long.valueOf(values[11]));
				else if(values[5].equals(CityB))
					context.getCounter(CityCounterGroup,CityB).increment(Long.valueOf(values[11]));
				else
					context.getCounter(CityCounterGroup,CityC).increment(Long.valueOf(values[11]));
				context.getCounter(CityCounterGroup,CityAll).increment(Long.valueOf(values[11]));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	

}
