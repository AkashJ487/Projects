package Project.Pro_PartitionerCity;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CityMapper extends Mapper<Object,Text,Text,Text>  {

	public void map(Object key, Text value, Context context)
			throws IOException, InterruptedException {
		
		String values[] = value.toString().split(",");
		Text city = new Text();
		try
		{
			if(!values[0].equals("User_ID"))
			{
				city.set(values[5]);
				context.write(city, value);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
