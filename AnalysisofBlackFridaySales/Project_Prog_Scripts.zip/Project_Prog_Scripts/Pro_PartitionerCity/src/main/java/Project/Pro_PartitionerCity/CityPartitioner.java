package Project.Pro_PartitionerCity;

import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Partitioner;

public class CityPartitioner extends Partitioner<Text, Text> implements Configurable{
	
	private static final String Min_City="City";
	private Configuration conf = null;
	private String city = "A";

	@Override
	public int getPartition(Text key, Text value, int numPartitions) {
		return key.toString().hashCode() - city.hashCode();
	}

	@Override
	public void setConf(Configuration conf) {
		this.conf=conf;
		city=conf.get(Min_City, "A");
		
	}

	@Override
	public Configuration getConf() {
		return conf;
	}
	
	public static void setMinCity(Job job, String city)
	{
		job.getConfiguration().set(Min_City, city);
	}

}
