package Project.Pro_PartitionerCity;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CityReducer extends Reducer<Object,Text,Text,NullWritable> {
	
	public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException
	{
		for(Text t: value)
			context.write(t, NullWritable.get());
			
	}

}
