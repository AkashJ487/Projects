package Project.Pro_SecSortProdPrice;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class ProdComparator extends WritableComparator{
	
	protected ProdComparator() {
		super(Product.class, true);
	}

	@Override
	public int compare(WritableComparable p11, WritableComparable p22) {
		
		Product p1=(Product) p11;
		Product p2 =(Product) p22;
		int comResult = p1.getProdID().compareTo(p2.getProdID());
		
		if (comResult == 0) {
				
				return -1*p1.getSum().compareTo(p2.getSum());
			
		}
		
		return comResult;
	}

}