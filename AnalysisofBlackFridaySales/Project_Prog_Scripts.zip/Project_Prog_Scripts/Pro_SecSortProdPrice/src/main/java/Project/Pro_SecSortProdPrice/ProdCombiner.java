package Project.Pro_SecSortProdPrice;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class ProdCombiner extends Reducer <Product, LongWritable, Product, LongWritable>{

	@Override
	protected void reduce(Product arg0, Iterable<LongWritable> arg1,
			Reducer<Product, LongWritable, Product, LongWritable>.Context arg2)
			throws IOException, InterruptedException {
		long sum = 0;
		LongWritable summ = new LongWritable();
		for (LongWritable val : arg1) {
			sum = sum + val.get();
		}
		try {
			summ.set(sum);
			arg0.setSum(sum);
			arg2.write(arg0, summ);
		}catch (Exception e) {
			//  handle exception
		}
	}

}