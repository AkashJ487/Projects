package Project.Pro_SecSortProdPrice;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ProdMapper extends Mapper <Object, Text, Product, NullWritable>{
	
	@Override
	public void map(Object key, Text value, Mapper<Object, Text, Product, NullWritable>.Context context)
			throws IOException, InterruptedException {
		String values[] = value.toString().split("	");
		String prodID = null;
		String city = null;
		Long sum = null;
		try {
			//if(!values[0].equals("User_ID"))
			//{
				prodID = values[0];
				city = values[1];
				sum = Long.valueOf(values[2]);
			//}
		}catch(Exception e) {
			// print()
		}
		System.out.println(prodID != null && city != null && sum!=null);
		if(prodID != null && city != null && sum!=null) {
			Product p = new Product(prodID, city, sum);
			
			try {
				System.out.println("===================="+p.getProdID()+p.getCity()+p.getSum()+"========================");
				context.write(p, NullWritable.get());
			}catch (Exception e) {
				// handle exception
			}
		}
	}

}
