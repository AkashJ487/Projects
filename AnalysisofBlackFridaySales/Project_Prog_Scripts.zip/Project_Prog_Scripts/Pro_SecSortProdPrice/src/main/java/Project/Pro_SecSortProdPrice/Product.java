package Project.Pro_SecSortProdPrice;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class Product implements Writable, WritableComparable<Product>{
	
	private String prodID;
	private String city;
	private Long sum;
	public Product() {
		super();
		prodID="";
		city="";
		sum=null;
	}
	public Product(String prodID, String city, Long sum) {
		super();
		this.prodID = prodID;
		this.city = city;
		this.sum = sum;
	}
	public String getProdID() {
		return prodID;
	}
	public void setProdID(String prodID) {
		this.prodID = prodID;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Long getSum() {
		return sum;
	}
	public void setSum(Long sum) {
		this.sum = sum;
	}
	@Override
	public int compareTo(Product o) {
		int r = this.prodID.compareTo(o.prodID);
		if(r==0)
		{
			r=this.sum.compareTo(o.sum);
		}
		
		return r;
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(prodID);
		out.writeUTF(city);
		out.writeLong(sum);
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		prodID = in.readUTF();
		city = in.readUTF();
		sum = in.readLong();	
	}
	
	@Override
	public String toString() {
		return "prodID=" + prodID + ", city=" + city + ", Amount=" + sum + "|";
	}
	
	
	
	
	
	

}
