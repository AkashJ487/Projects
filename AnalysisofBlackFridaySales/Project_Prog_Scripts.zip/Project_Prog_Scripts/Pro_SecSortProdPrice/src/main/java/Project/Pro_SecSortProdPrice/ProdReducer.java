package Project.Pro_SecSortProdPrice;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class ProdReducer extends Reducer <Product, NullWritable, Product, NullWritable>{

	@Override
	protected void reduce(Product arg0, Iterable<NullWritable> arg1,
			Reducer<Product, NullWritable, Product, NullWritable>.Context arg2)
			throws IOException, InterruptedException {
		
		for (NullWritable val : arg1) {
			arg2.write(arg0,val);
		}
	}

}