package Project.Pro_SecSortProdPrice;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Partitioner;

public class ProdPartitioner extends Partitioner <Product, LongWritable>{

	@Override
	public int getPartition(Product arg0, LongWritable arg1, int numOfReducerTasks) {
		int hash = arg0.getProdID().hashCode();
		int partition = hash % numOfReducerTasks;
		return partition;
	}

}