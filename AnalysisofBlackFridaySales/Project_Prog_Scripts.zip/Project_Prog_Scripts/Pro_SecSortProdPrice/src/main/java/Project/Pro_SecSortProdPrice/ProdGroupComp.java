package Project.Pro_SecSortProdPrice;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class ProdGroupComp extends WritableComparator{

	protected ProdGroupComp() {
		super(Product.class, true);
	}

	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		
		Product p1 = (Product) a;
		Product p2 = (Product) b;
		
		int comResult = p1.getProdID().compareTo(p2.getProdID());
		
		return comResult;
	}
}