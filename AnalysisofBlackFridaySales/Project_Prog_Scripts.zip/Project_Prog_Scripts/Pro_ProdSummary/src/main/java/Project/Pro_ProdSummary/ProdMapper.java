package Project.Pro_ProdSummary;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ProdMapper extends Mapper<LongWritable, Text, Text, LongWritable>{

	LongWritable movieId = new LongWritable();
	LongWritable rating = new LongWritable();
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, LongWritable>.Context context)
			throws IOException, InterruptedException {
		Text prod = new Text();
		String prodID = "";
		Long sum = Long.valueOf(0);
		LongWritable summ = new LongWritable();
		String values[] = value.toString().split(",");
		try {
			if(!values[0].equals("User_ID"))
			{
				prodID = values[1];
				sum = Long.valueOf(values[11]);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		prod.set(prodID);
		summ.set(sum);
		context.write(prod, summ);
	}
}