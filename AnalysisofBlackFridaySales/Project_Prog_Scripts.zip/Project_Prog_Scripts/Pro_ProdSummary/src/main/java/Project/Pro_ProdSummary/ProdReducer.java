package Project.Pro_ProdSummary;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ProdReducer extends Reducer <Text, LongWritable, Text, ProdSummary>{

	
	List<Long> ratingList = new ArrayList<Long>();
	
	@Override
	protected void reduce(Text arg0, Iterable<LongWritable> arg1,
			Reducer<Text, LongWritable, Text, ProdSummary>.Context arg2)
			throws IOException, InterruptedException {
		
		int counter = 0;
		double sum = 0.0;
		double min=Double.MAX_VALUE;
		double max=0;
		
		for (LongWritable val : arg1) {
			ratingList.add(val.get());
			counter += 1;
			sum += val.get();
			if(min > val.get())
				min=val.get();
			if(max<val.get())
				max=val.get();
			
		}
		
		Collections.sort(ratingList);
		System.out.println("Key " + arg0 + "Length " + ratingList.size());
		//find median
		double median;
		if (counter % 2 == 0) {
			median = (ratingList.get(counter/2 - 1) + ratingList.get(counter/2)) / 2;
		}else {
			median = ratingList.get(counter/2);
		}
		
		//find StdDev
		double means = sum/counter;
		double sumOfSqares = 0.0;
		for(double d : ratingList) {
			sumOfSqares += (d - means) * (d - means);
		}
		double stdDev = Math.sqrt(sumOfSqares/(counter-1));
		ratingList.clear();
		ProdSummary result = new ProdSummary(String.valueOf(means),String.valueOf(median),String.valueOf(stdDev),
				String.valueOf(max),String.valueOf(min),String.valueOf(sum),String.valueOf(counter));
		arg2.write(arg0, result);
	}

}