package Project.Pro_ProdSummary;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;



public class ProdSummary implements Writable {

	public String avg;
	public String median;
	public String stdDev;
	public String maxPrice;
	public String minPrice;
	public String sum;
	public String count;
	
	

	public ProdSummary(String avg, String median, String stdDev, String maxPrice, String minPrice,String sum, String count) {
		super();
		this.avg = avg;
		this.median = median;
		this.stdDev = stdDev;
		this.maxPrice = maxPrice;
		this.minPrice = minPrice;
		this.count=count;
		this.sum=sum;
	}
	
	

	public String getAvg() {
		return avg;
	}



	public void setAvg(String avg) {
		this.avg = avg;
	}



	public String getMedian() {
		return median;
	}



	public void setMedian(String median) {
		this.median = median;
	}



	public String getStdDev() {
		return stdDev;
	}



	public void setStdDev(String stdDev) {
		this.stdDev = stdDev;
	}



	public String getMaxPrice() {
		return maxPrice;
	}



	public void setMaxPrice(String maxPrice) {
		this.maxPrice = maxPrice;
	}



	public String getMinPrice() {
		return minPrice;
	}



	public void setMinPrice(String minPrice) {
		this.minPrice = minPrice;
	}

	
	public String getSum() {
		return sum;
	}

	public void setSum(String sum) {
		this.sum = sum;
	}



	public String getCount() {
		return count;
	}



	public void setCount(String count) {
		this.count = count;
	}



	@Override
	public void write(DataOutput out) throws IOException {
		
		out.writeUTF(avg);
		out.writeUTF(median);
		out.writeUTF(stdDev);
		out.writeUTF(maxPrice);
		out.writeUTF(minPrice);
		out.writeUTF(sum);
		out.writeUTF(count);
		
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		
		avg = in.readUTF();
		median = in.readUTF();
		stdDev = in.readUTF();
		maxPrice = in.readUTF();
		minPrice = in.readUTF();
		sum = in.readUTF();
		count = in.readUTF();
	}



	@Override
	public String toString() {
		return avg + "	" + median + "	" + stdDev + "	" + maxPrice
				+ "	" + minPrice + "	" + sum + "	" + count;
	}
	
	
}
