echo "Enter the product id"
read prodID
aaa=`hadoop fs -cat /Project/Output/ProdSummary/* | grep $prodID`
bbb=`hadoop fs -cat /Project/Output/SecSort/Output/* | grep $prodID`
ccc=`hadoop fs -cat /Project/Output/BestCity4Prod/* | grep $prodID`
if [ $? -eq 0 ]
then
    echo " "
    echo "$(tput setaf 1)--------------------------------Summarry of Product--------------------------------------"
    echo " "
    echo "$(tput setaf 1)ProductID Avg_Price 	     Median  StdDev_in_Price	Max  	Min    Total	 Count"
    echo $aaa
    echo " "
    echo "--------------------------------City Wise Collection-------------------------------------"
    echo " "
    echo $bbb
    echo " "
    echo "------------------------Best City for Sale of this Product-------------------------------"
    echo " "
    echo $ccc | awk '{print "City : " $2 ", Amount : " $3}' 
else
    echo "********************Product of the given ID doesnt exist as of now***********************"
fi
