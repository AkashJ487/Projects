package Project.Pro_BestCity4Product;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ProdReducer extends Reducer <Text, CityPrice, Text, CityPrice>{

	@Override
	protected void reduce(Text arg0, Iterable<CityPrice> arg1,
			Reducer<Text, CityPrice, Text, CityPrice>.Context arg2)
			throws IOException, InterruptedException {
		
		CityPrice maxPrice = new CityPrice("",Long.MIN_VALUE);
		
		for (CityPrice val : arg1) {
			
			if(val.getSum() > maxPrice.getSum())
			{
				maxPrice.setSum(val.getSum());
				maxPrice.setCity(val.getCity());
			}	
		}
		
		arg2.write(arg0,maxPrice);
	}

}