package Project.Pro_BestCity4Product;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ProdMapper extends Mapper <Object, Text, Text, CityPrice>{
	
	@Override
	public void map(Object key, Text value, Mapper<Object, Text, Text, CityPrice>.Context context)
			throws IOException, InterruptedException {
		String values[] = value.toString().split("	");
		Text t = new Text();
		String city = null;
		Long sum = null;
		try {
				t.set(values[0]);
				city = values[1];
				sum = Long.valueOf(values[2]);
		}catch(Exception e) {
			// print()
		}
		if(city != null && sum!=null) {
			CityPrice cp = new CityPrice(city, sum);
			
			try {
				context.write(t, cp);
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}