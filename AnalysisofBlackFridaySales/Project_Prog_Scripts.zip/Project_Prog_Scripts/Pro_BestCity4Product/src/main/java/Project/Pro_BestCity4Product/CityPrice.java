package Project.Pro_BestCity4Product;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class CityPrice implements Writable{
	
	private String city;
	private Long sum;
	
	public CityPrice() {
		super();
		city="";
		sum=null;
	}
	public CityPrice(String city, Long sum) {
		super();
		this.city = city;
		this.sum = sum;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Long getSum() {
		return sum;
	}
	public void setSum(Long sum) {
		this.sum = sum;
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(city);
		out.writeLong(sum);
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		city = in.readUTF();
		sum = in.readLong();	
	}
	
	@Override
	public String toString() {
		return city + "	" + sum;
	}

}
