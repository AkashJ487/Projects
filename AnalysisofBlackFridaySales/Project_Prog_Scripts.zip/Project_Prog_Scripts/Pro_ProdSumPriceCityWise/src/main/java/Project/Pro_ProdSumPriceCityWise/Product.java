package Project.Pro_ProdSumPriceCityWise;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;


public class Product implements WritableComparable<Product>{
	
	private String prodID;
	private String city;
	public Product() {
		super();
		prodID="";
		city="";
	}
	public Product(String prodID, String city) {
		super();
		this.prodID = prodID;
		this.city = city;
	}
	public String getProdID() {
		return prodID;
	}
	public void setProdID(String prodID) {
		this.prodID = prodID;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public int compareTo(Product o) {
		int r = this.prodID.compareTo(o.prodID);
		if(r==0)
		{
			r=this.city.compareTo(o.city);
		}
		
		return r;
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(prodID);
		out.writeUTF(city);
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		prodID = in.readUTF();
		city = in.readUTF();	
	}
	
	@Override
	public String toString() {
		return prodID +"	"+ city;
	}
	
	
	
	
	
	

}