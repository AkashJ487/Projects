package Project.Pro_ProdSumPriceCityWise;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;


public class ProdReducer extends Reducer <Product, LongWritable, Product, LongWritable>{

	long sum=0;
	LongWritable summ = new LongWritable();
	@Override
	protected void reduce(Product arg0, Iterable<LongWritable> arg1,
			Reducer<Product, LongWritable, Product, LongWritable>.Context arg2)
			throws IOException, InterruptedException {
		
		for (LongWritable val : arg1) {
			sum = sum + val.get();
		}
		summ.set(sum);
		arg2.write(arg0,summ);
	}

}